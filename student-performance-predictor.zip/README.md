# Student Performance Predictor

This is a beginner-friendly machine learning project that predicts a student's final score based on study time, sleep, and attendance.

## Features
- User input via sliders (Study hours, Sleep hours, Attendance %)
- Real-time prediction using a trained ML model
- Visual bar chart of input summary

## Tech Stack
Python, Pandas, Scikit-learn, Streamlit, Matplotlib

## How to Run
1. Install requirements:
```
pip install streamlit pandas scikit-learn matplotlib joblib
```
2. Run the app:
```
streamlit run app.py
```