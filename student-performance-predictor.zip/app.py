import streamlit as st
import pandas as pd
import joblib
import matplotlib.pyplot as plt

st.title("Student Performance Predictor")
st.markdown("Enter your routine details to estimate your exam score.")

# Load model
model = joblib.load("model.pkl")

# User Inputs
study_hours = st.slider("Study Hours per Day", 0.0, 10.0, 2.0)
sleep_hours = st.slider("Sleep Hours per Day", 0.0, 10.0, 6.0)
attendance = st.slider("Attendance (%)", 0, 100, 75)

# Prediction
input_data = pd.DataFrame([[study_hours, sleep_hours, attendance]],
                          columns=["Study_Hours", "Sleep_Hours", "Attendance"])
predicted_score = model.predict(input_data)[0]
st.subheader(f"Predicted Score: {predicted_score:.2f}")

# Visualization
st.markdown("### Your Input Summary")
fig, ax = plt.subplots()
ax.bar(["Study", "Sleep", "Attendance"], [study_hours, sleep_hours, attendance], color=["#4CAF50", "#2196F3", "#FFC107"])
ax.set_ylabel("Values")
st.pyplot(fig)